package microgram.impl.srv.rest;

import microgram.api.java.Posts;
import microgram.api.rest.RestMediaStorage;
import microgram.impl.srv.java.JavaMedia;
import microgram.impl.srv.java.JavaPosts;

public class RestMediaResources extends RestResource implements RestMediaStorage {

	
	final String baseUri;
	final JavaMedia impl;
	
	public RestMediaResources(String baseUri ) {
		this.baseUri = baseUri + RestMediaStorage.PATH;
		this.impl = createMedia ();
	}
	private synchronized JavaMedia createMedia () {
		JavaMedia tmp = new JavaMedia();
		return tmp;
	}
	
	@Override
	public String upload(byte[] bytes) {
		return super.resultOrThrow(impl.upload(bytes));
	}

	@Override
	public byte[] download(String id) {
		return super.resultOrThrow(impl.download(id));
 	}

	@Override
	public void delete(String id) {
		super.resultOrThrow(impl.delete(id));
	}
	
	
}
